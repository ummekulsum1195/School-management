import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import StudentList from './components/StudentList';
import TeacherList from './components/TeacherList';
import CourseList from './components/CourseList';
import AIAssistant from './components/AIAssistant';
import AdmissionForm from './components/AdmissionForm';
import LoginPage from './components/LoginPage';
import type { View, Student, Teacher, Course, Admission } from './types';
import { students as mockStudents, teachers as mockTeachers, courses as mockCourses } from './data/mockData';

type NewStudentData = Omit<Student, 'id'>;
type NewTeacherData = Omit<Teacher, 'id'>;
type NewCourseData = Omit<Course, 'id'>;

type NewAdmissionData = {
  studentName: string;
  grade: string;
  email: string;
  phone: string;
};

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [view, setView] = useState<View>('dashboard');
  const [students, setStudents] = useState<Student[]>(mockStudents);
  const [teachers, setTeachers] = useState<Teacher[]>(mockTeachers);
  const [courses, setCourses] = useState<Course[]>(mockCourses);
  const [admissions, setAdmissions] = useState<Admission[]>([]);

  const handleLoginSuccess = () => {
    setIsAuthenticated(true);
  };
  
  // Student Handlers
  const handleAddStudent = (studentData: NewStudentData) => {
    const newStudent: Student = {
      id: `S${Date.now()}`,
      ...studentData,
      imageUrl: studentData.imageUrl || `https://i.pravatar.cc/150?u=S${Date.now()}`,
    };
    setStudents(prev => [...prev, newStudent]);
  };

  const handleEditStudent = (updatedStudent: Student) => {
    setStudents(prev => prev.map(s => s.id === updatedStudent.id ? updatedStudent : s));
  };
  
  const handleRemoveStudent = (studentId: string) => {
    setStudents(prev => prev.filter(student => student.id !== studentId));
    // Also remove student from any courses they were enrolled in
    setCourses(prevCourses => prevCourses.map(course => ({
      ...course,
      studentIds: course.studentIds.filter(id => id !== studentId),
    })));
  };

  // Teacher Handlers
  const handleAddTeacher = (teacherData: NewTeacherData) => {
    const newTeacher: Teacher = {
      id: `T${Date.now()}`,
      ...teacherData,
      imageUrl: teacherData.imageUrl || `https://i.pravatar.cc/150?u=T${Date.now()}`,
    };
    setTeachers(prev => [...prev, newTeacher]);
  };

  const handleEditTeacher = (updatedTeacher: Teacher) => {
    setTeachers(prev => prev.map(t => t.id === updatedTeacher.id ? updatedTeacher : t));
  };

  const handleRemoveTeacher = (teacherId: string) => {
    setTeachers(prev => prev.filter(teacher => teacher.id !== teacherId));
    // Unassign teacher from any courses they were teaching
    setCourses(prevCourses => prevCourses.map(course => 
        course.teacherId === teacherId ? { ...course, teacherId: '' } : course
    ));
  };

  // Course Handlers
  const handleAddCourse = (courseData: NewCourseData) => {
    const newCourse: Course = {
      id: `C${Date.now()}`,
      ...courseData,
    };
    setCourses(prev => [...prev, newCourse]);
  };

  const handleRemoveCourse = (courseId: string) => {
    setCourses(prev => prev.filter(course => course.id !== courseId));
  };

  // Admission Handlers
  const handleAddAdmission = (formData: NewAdmissionData) => {
    const newAdmission: Admission = {
      id: `ADM${Date.now()}`,
      studentName: formData.studentName,
      grade: parseInt(formData.grade, 10),
      email: formData.email,
      phone: formData.phone,
      status: 'Pending',
    };
    setAdmissions(prev => [...prev, newAdmission]);
  };

  const handleRemoveAdmission = (admissionId: string) => {
    setAdmissions(prev => prev.filter(admission => admission.id !== admissionId));
  };
  
  const handleEditAdmission = (updatedAdmission: Admission) => {
    setAdmissions(prev =>
      prev.map(admission =>
        admission.id === updatedAdmission.id ? updatedAdmission : admission
      )
    );
  };

  const allData = { students, teachers, courses, admissions };

  const renderView = () => {
    switch (view) {
      case 'dashboard':
        return <Dashboard students={students} teachers={teachers} courses={courses} />;
      case 'students':
        return <StudentList students={students} onAddStudent={handleAddStudent} onEditStudent={handleEditStudent} onRemoveStudent={handleRemoveStudent} />;
      case 'teachers':
        return <TeacherList teachers={teachers} onAddTeacher={handleAddTeacher} onEditTeacher={handleEditTeacher} onRemoveTeacher={handleRemoveTeacher} />;
      case 'courses':
        return <CourseList courses={courses} teachers={teachers} students={students} onAddCourse={handleAddCourse} onRemoveCourse={handleRemoveCourse} />;
      case 'admissions':
        return <AdmissionForm admissions={admissions} onAddAdmission={handleAddAdmission} onEditAdmission={handleEditAdmission} onRemoveAdmission={handleRemoveAdmission} />;
      default:
        return <Dashboard students={students} teachers={teachers} courses={courses} />;
    }
  };

  if (!isAuthenticated) {
    return <LoginPage onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="flex h-screen bg-light-bg dark:bg-dark-bg font-sans">
      <Sidebar view={view} setView={setView} />
      <main className="flex-1 flex flex-col overflow-hidden">
        <div className="flex-1 overflow-x-hidden overflow-y-auto bg-light-bg dark:bg-dark-bg">
          <div className="container mx-auto px-6 py-8">
            {renderView()}
          </div>
        </div>
      </main>
      <AIAssistant allData={allData} />
    </div>
  );
};

export default App;