import type { Student, Teacher, Course } from '../types';

export const students: Student[] = [
  { id: 'S001', name: 'Alice Johnson', grade: 10, email: 'alice.j@example.com', phone: '555-0111', attendance: 95, marks: 95, imageUrl: 'https://i.pravatar.cc/150?u=S001' },
  { id: 'S002', name: 'Bob Smith', grade: 11, email: 'bob.s@example.com', phone: '555-0112', attendance: 92, marks: 88, imageUrl: 'https://i.pravatar.cc/150?u=S002' },
  { id: 'S003', name: 'Charlie Brown', grade: 9, email: 'charlie.b@example.com', phone: '555-0113', attendance: 98, marks: 100, imageUrl: 'https://i.pravatar.cc/150?u=S003' },
  { id: 'S004', name: 'Diana Prince', grade: 12, email: 'diana.p@example.com', phone: '555-0114', attendance: 88, marks: 80, imageUrl: 'https://i.pravatar.cc/150?u=S004' },
  { id: 'S005', name: 'Ethan Hunt', grade: 10, email: 'ethan.h@example.com', phone: '555-0115', attendance: 96, marks: 98, imageUrl: 'https://i.pravatar.cc/150?u=S005' },
  { id: 'S006', name: 'Fiona Glenanne', grade: 11, email: 'fiona.g@example.com', phone: '555-0116', attendance: 91, marks: 85, imageUrl: 'https://i.pravatar.cc/150?u=S006' },
  { id: 'S007', name: 'George Costanza', grade: 9, email: 'george.c@example.com', phone: '555-0117', attendance: 85, marks: 70, imageUrl: 'https://i.pravatar.cc/150?u=S007' },
  { id: 'S008', name: 'Hannah Montana', grade: 12, email: 'hannah.m@example.com', phone: '555-0118', attendance: 99, marks: 100, imageUrl: 'https://i.pravatar.cc/150?u=S008' },
];

export const teachers: Teacher[] = [
  { id: 'T01', name: 'Dr. Evelyn Reed', subject: 'Physics', email: 'e.reed@school.edu', phone: '555-0101', imageUrl: 'https://i.pravatar.cc/150?u=T01' },
  { id: 'T02', name: 'Mr. David Chen', subject: 'Mathematics', email: 'd.chen@school.edu', phone: '555-0102', imageUrl: 'https://i.pravatar.cc/150?u=T02' },
  { id: 'T03', name: 'Ms. Maria Garcia', subject: 'History', email: 'm.garcia@school.edu', phone: '555-0103', imageUrl: 'https://i.pravatar.cc/150?u=T03' },
  { id: 'T04', name: 'Mrs. Olivia White', subject: 'English', email: 'o.white@school.edu', phone: '555-0104', imageUrl: 'https://i.pravatar.cc/150?u=T04' },
];

export const courses: Course[] = [
  { id: 'PHY101', title: 'Introduction to Physics', teacherId: 'T01', department: 'Science', credits: 4, studentIds: ['S001', 'S002', 'S005'] },
  { id: 'MAT201', title: 'Calculus II', teacherId: 'T02', department: 'Mathematics', credits: 4, studentIds: ['S002', 'S004', 'S006'] },
  { id: 'HIS101', title: 'World History', teacherId: 'T03', department: 'Humanities', credits: 3, studentIds: ['S001', 'S003', 'S007'] },
  { id: 'ENG202', title: 'American Literature', teacherId: 'T04', department: 'Humanities', credits: 3, studentIds: ['S003', 'S005', 'S008'] },
  { id: 'MAT101', title: 'Algebra I', teacherId: 'T02', department: 'Mathematics', credits: 3, studentIds: ['S003', 'S007'] },
];

export const allData = { students, teachers, courses };