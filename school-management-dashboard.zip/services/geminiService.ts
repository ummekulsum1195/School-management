
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  // This is a fallback for development. In a real environment, the key should be set.
  console.warn("Gemini API key not found. Please set the API_KEY environment variable.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export async function getAIResponse(prompt: string, contextData: object): Promise<string> {
  if (!API_KEY) {
    return "Gemini API key is not configured. Please check your environment variables.";
  }
  
  const fullPrompt = `
    You are an intelligent school management assistant. Your task is to answer questions based on the provided school data.
    The data is in JSON format. Be concise and helpful in your responses. If the user asks for a list, format it clearly.

    School Data:
    ${JSON.stringify(contextData, null, 2)}

    User's Question:
    "${prompt}"

    Your Answer:
  `;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: fullPrompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return "Sorry, I encountered an error while processing your request. Please try again.";
  }
}
