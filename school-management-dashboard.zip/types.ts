export interface Student {
  id: string;
  name: string;
  imageUrl: string;
  grade: number;
  email: string;
  phone: string;
  attendance: number;
  marks: number;
}

export interface Teacher {
  id: string;
  name: string;
  imageUrl: string;
  subject: string;
  email: string;
  phone: string;
}

export interface Course {
  id: string;
  title: string;
  teacherId: string;
  department: string;
  credits: number;
  studentIds: string[];
}

export interface Admission {
  id: string;
  studentName: string;
  grade: number;
  email: string;
  phone: string;
  status: 'Pending' | 'Accepted' | 'Rejected';
}

export type View = 'dashboard' | 'students' | 'teachers' | 'courses' | 'admissions';