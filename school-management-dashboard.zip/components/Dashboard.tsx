import React from 'react';
import { UsersIcon, AcademicCapIcon, BookOpenIcon, ChartBarIcon } from './icons/Icons';
import type { Student, Teacher, Course } from '../types';

const StatCard: React.FC<{ icon: React.ReactNode; title: string; value: string | number; color: string }> = ({ icon, title, value, color }) => (
  <div className="bg-light-card dark:bg-dark-card p-6 rounded-xl shadow-md flex items-center space-x-4 transition-transform hover:scale-105">
    <div className={`p-3 rounded-full ${color}`}>
      {icon}
    </div>
    <div>
      <p className="text-sm font-medium text-light-text dark:text-gray-400">{title}</p>
      <p className="text-2xl font-bold text-gray-800 dark:text-white">{value}</p>
    </div>
  </div>
);


const Dashboard: React.FC<{ students: Student[], teachers: Teacher[], courses: Course[] }> = ({ students, teachers, courses }) => {
  const latestStudents = students.slice(-3);
  const totalStudents = students.length;
  const totalTeachers = teachers.length;
  const totalCourses = courses.length;
  const avgAttendance = totalStudents > 0 ? (students.reduce((acc, s) => acc + s.attendance, 0) / totalStudents).toFixed(1) + '%' : '0%';
  
  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-6">Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard icon={<UsersIcon />} title="Total Students" value={totalStudents} color="bg-blue-100 text-blue-600 dark:bg-blue-900/50 dark:text-blue-300" />
        <StatCard icon={<AcademicCapIcon />} title="Total Teachers" value={totalTeachers} color="bg-emerald-100 text-emerald-600 dark:bg-emerald-900/50 dark:text-emerald-300" />
        <StatCard icon={<BookOpenIcon />} title="Total Courses" value={totalCourses} color="bg-purple-100 text-purple-600 dark:bg-purple-900/50 dark:text-purple-300" />
        <StatCard icon={<ChartBarIcon />} title="Avg. Attendance" value={avgAttendance} color="bg-amber-100 text-amber-600 dark:bg-amber-900/50 dark:text-amber-300" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-light-card dark:bg-dark-card p-6 rounded-xl shadow-md">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Recent Enrollments</h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="text-xs font-semibold tracking-wide text-light-text uppercase border-b dark:border-dark-border">
                  <th className="px-4 py-3">Name</th>
                  <th className="px-4 py-3">Grade</th>
                  <th className="px-4 py-3">Marks</th>
                </tr>
              </thead>
              <tbody className="bg-white dark:bg-dark-card divide-y dark:divide-dark-border">
                {latestStudents.map(student => (
                  <tr key={student.id} className="text-gray-700 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800">
                    <td className="px-4 py-3">
                      <div className="flex items-center text-sm">
                        <div className="relative hidden w-8 h-8 mr-3 rounded-full md:block">
                           <img className="object-cover w-full h-full rounded-full" src={student.imageUrl} alt="" loading="lazy" />
                           <div className="absolute inset-0 rounded-full shadow-inner" aria-hidden="true"></div>
                        </div>
                        <div>
                           <p className="font-semibold">{student.name}</p>
                           <p className="text-xs text-gray-600 dark:text-gray-500">{student.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm">{student.grade}</td>
                    <td className="px-4 py-3 text-sm font-semibold">{student.marks}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="bg-light-card dark:bg-dark-card p-6 rounded-xl shadow-md">
           <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">Top Courses</h2>
           <ul className="space-y-4">
              {courses.slice(0, 4).map(course => {
                  const teacher = teachers.find(t => t.id === course.teacherId);
                  return (
                      <li key={course.id} className="flex items-start space-x-3">
                          <div className="p-2 bg-brand-primary/10 rounded-full">
                              <BookOpenIcon className="w-5 h-5 text-brand-primary" />
                          </div>
                          <div>
                              <p className="font-semibold text-gray-800 dark:text-white">{course.title}</p>
                              <p className="text-sm text-light-text dark:text-gray-400">by {teacher?.name}</p>
                          </div>
                      </li>
                  );
              })}
           </ul>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;