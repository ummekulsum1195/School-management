import React, { useState } from 'react';
import type { View } from '../types';
import { HomeIcon, UsersIcon, AcademicCapIcon, BookOpenIcon, MenuIcon, XIcon, ClipboardListIcon } from './icons/Icons';

interface SidebarProps {
  view: View;
  setView: (view: View) => void;
}

const NavItem: React.FC<{
  viewName: View;
  currentView: View;
  setView: (view: View) => void;
  icon: React.ReactNode;
  label: string;
}> = ({ viewName, currentView, setView, icon, label }) => {
  const isActive = currentView === viewName;
  return (
    <a
      href="#"
      onClick={(e) => {
        e.preventDefault();
        setView(viewName);
      }}
      className={`flex items-center px-4 py-3 text-gray-700 dark:text-gray-200 rounded-lg transition-colors duration-200 ${
        isActive
          ? 'bg-brand-primary text-white font-semibold shadow-lg'
          : 'hover:bg-gray-200 dark:hover:bg-gray-700'
      }`}
    >
      {icon}
      <span className="mx-4 font-medium">{label}</span>
    </a>
  );
};

const Sidebar: React.FC<SidebarProps> = ({ view, setView }) => {
  const [isOpen, setIsOpen] = useState(false);

  const navigationItems = (
    <>
      <NavItem viewName="dashboard" currentView={view} setView={setView} icon={<HomeIcon />} label="Dashboard" />
      <NavItem viewName="students" currentView={view} setView={setView} icon={<UsersIcon />} label="Students" />
      <NavItem viewName="teachers" currentView={view} setView={setView} icon={<AcademicCapIcon />} label="Teachers" />
      <NavItem viewName="courses" currentView={view} setView={setView} icon={<BookOpenIcon />} label="Courses" />
      <NavItem viewName="admissions" currentView={view} setView={setView} icon={<ClipboardListIcon />} label="Admissions" />
    </>
  );

  return (
    <>
      {/* Mobile Menu Button */}
      <button onClick={() => setIsOpen(!isOpen)} className="fixed top-4 left-4 z-30 lg:hidden p-2 rounded-md bg-white/50 dark:bg-dark-card/50 backdrop-blur-sm text-gray-600 dark:text-gray-300">
        {isOpen ? <XIcon /> : <MenuIcon />}
      </button>

      {/* Sidebar */}
      <aside className={`z-20 flex-shrink-0 w-64 px-2 py-4 bg-light-card dark:bg-dark-card border-r dark:border-dark-border flex-col justify-between transition-transform duration-300 ease-in-out ${isOpen ? 'flex' : 'hidden'} lg:flex fixed lg:relative h-full`}>
        <div>
          <h2 className="px-4 text-2xl font-bold text-gray-800 dark:text-white">
            Academia<span className="text-brand-primary">Plus</span>
          </h2>
          <nav className="mt-8 space-y-2">
            {navigationItems}
          </nav>
        </div>
         <div className="px-4 mt-auto">
            <p className="text-xs text-light-text dark:text-gray-500">© 2024 AcademiaPlus</p>
         </div>
      </aside>
       {isOpen && <div onClick={() => setIsOpen(false)} className="fixed inset-0 bg-black/30 z-10 lg:hidden"></div>}
    </>
  );
};

export default Sidebar;