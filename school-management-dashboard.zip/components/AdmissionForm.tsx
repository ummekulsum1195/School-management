import React, { useState } from 'react';
import type { Admission } from '../types';
import { EditIcon, TrashIcon } from './icons/Icons';
import AdmissionModal from './AdmissionModal';

type NewAdmissionData = {
  studentName: string;
  grade: string;
  email: string;
  phone: string;
};

interface AdmissionFormProps {
  admissions: Admission[];
  onAddAdmission: (data: NewAdmissionData) => void;
  onEditAdmission: (admission: Admission) => void;
  onRemoveAdmission: (id: string) => void;
}

const AdmissionForm: React.FC<AdmissionFormProps> = ({ admissions, onAddAdmission, onEditAdmission, onRemoveAdmission }) => {
  const initialFormState = {
    studentName: '',
    grade: '1',
    email: '',
    phone: '',
  };
  const [formData, setFormData] = useState(initialFormState);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingAdmission, setEditingAdmission] = useState<Admission | null>(null);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const validate = (): boolean => {
    const newErrors: { [key: string]: string } = {};
    if (!formData.studentName.trim()) newErrors.studentName = 'Student name is required';
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email address is invalid';
    }
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (formData.phone.replace(/\D/g, '').length < 7) {
        newErrors.phone = 'Please enter a valid phone number (at least 7 digits).';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onAddAdmission(formData);
      setIsSubmitted(true);
      setFormData(initialFormState);
      setTimeout(() => setIsSubmitted(false), 5000); // Hide success message after 5 seconds
    }
  };
  
  const statusColors = {
    Pending: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/50 dark:text-yellow-300',
    Accepted: 'bg-green-100 text-green-800 dark:bg-green-900/50 dark:text-green-300',
    Rejected: 'bg-red-100 text-red-800 dark:bg-red-900/50 dark:text-red-300',
  };

  const handleOpenEditModal = (admission: Admission) => {
    setEditingAdmission(admission);
    setIsEditModalOpen(true);
  };
  
  const handleCloseEditModal = () => {
    setEditingAdmission(null);
    setIsEditModalOpen(false);
  };
  
  const handleSaveEdit = (updatedAdmission: Admission) => {
    onEditAdmission(updatedAdmission);
    handleCloseEditModal();
  };

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-6">Admissions</h1>
      <div className="bg-light-card dark:bg-dark-card rounded-lg shadow-md p-6 md:p-8 max-w-2xl mx-auto">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">New Application</h2>
        {isSubmitted && (
            <div className="mb-6 p-4 bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-700 rounded-lg">
                <p className="font-bold">Application Submitted!</p>
                <p>Thank you! Your admission form has been received and added to the list below.</p>
            </div>
        )}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="studentName" className="block text-sm font-medium text-light-text dark:text-gray-300">Student's Full Name</label>
            <input type="text" name="studentName" id="studentName" value={formData.studentName} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-light-border dark:border-dark-border rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm dark:bg-dark-bg dark:text-white" />
            {errors.studentName && <p className="text-red-500 text-xs mt-1">{errors.studentName}</p>}
          </div>
          
          <div>
            <label htmlFor="grade" className="block text-sm font-medium text-light-text dark:text-gray-300">Applying for Grade</label>
            <select name="grade" id="grade" value={formData.grade} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-light-border dark:border-dark-border rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm dark:bg-dark-bg dark:text-white">
              {Array.from({ length: 12 }, (_, i) => i + 1).map(g => <option key={g} value={g}>Grade {g}</option>)}
            </select>
          </div>

          <div className="border-t dark:border-dark-border pt-6">
             <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">Parent/Guardian Information</h3>
             <div className="space-y-6">
                <div>
                    <label htmlFor="email" className="block text-sm font-medium text-light-text dark:text-gray-300">Email Address</label>
                    <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-light-border dark:border-dark-border rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm dark:bg-dark-bg dark:text-white" />
                    {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
                </div>
                <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-light-text dark:text-gray-300">Phone Number</label>
                    <input type="text" name="phone" id="phone" value={formData.phone} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-light-border dark:border-dark-border rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm dark:bg-dark-bg dark:text-white" placeholder="e.g., 555-0111"/>
                    {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
                </div>
             </div>
          </div>
          
          <div className="flex justify-end pt-4">
            <button type="submit" className="px-6 py-2 bg-brand-primary text-white rounded-lg shadow-md hover:bg-brand-primary/90 focus:outline-none focus:ring-2 focus:ring-brand-primary focus:ring-offset-2 transition-colors">
              Submit Application
            </button>
          </div>
        </form>
      </div>

      <div className="mt-12">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">Submitted Applications</h2>
        <div className="w-full overflow-hidden rounded-lg shadow-md">
          <div className="w-full overflow-x-auto">
            <table className="w-full whitespace-no-wrap">
              <thead>
                <tr className="text-xs font-semibold tracking-wide text-left text-light-text uppercase border-b dark:border-dark-border bg-gray-50 dark:text-gray-400 dark:bg-dark-card">
                  <th className="px-4 py-3">Student Name</th>
                  <th className="px-4 py-3">Grade</th>
                  <th className="px-4 py-3">Parent Contact</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y dark:divide-dark-border dark:bg-dark-card">
                {admissions.length > 0 ? admissions.map((admission: Admission) => (
                  <tr key={admission.id} className="text-gray-700 dark:text-gray-400">
                    <td className="px-4 py-3 text-sm font-semibold">{admission.studentName}</td>
                    <td className="px-4 py-3 text-sm">{admission.grade}</td>
                    <td className="px-4 py-3 text-sm">
                      <div>{admission.email}</div>
                      <div className="text-xs text-gray-500">{admission.phone}</div>
                    </td>
                    <td className="px-4 py-3 text-xs">
                      <span className={`px-2 py-1 font-semibold leading-tight rounded-full ${statusColors[admission.status]}`}>
                        {admission.status}
                      </span>
                    </td>
                     <td className="px-4 py-3 text-sm">
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => handleOpenEditModal(admission)}
                            className="p-1 text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors"
                            aria-label={`Edit ${admission.studentName}`}
                          >
                            <EditIcon />
                          </button>
                          <button
                            onClick={() => onRemoveAdmission(admission.id)}
                            className="p-1 text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500 transition-colors"
                            aria-label={`Remove ${admission.studentName}`}
                          >
                            <TrashIcon />
                          </button>
                        </div>
                      </td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan={5} className="text-center py-4 text-gray-500 dark:text-gray-400">
                      No applications submitted yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      {isEditModalOpen && editingAdmission && (
        <AdmissionModal
          admissionToEdit={editingAdmission}
          onClose={handleCloseEditModal}
          onSave={handleSaveEdit}
        />
      )}
    </div>
  );
};

export default AdmissionForm;