import React, { useState, useEffect } from 'react';
import type { Admission } from '../types';
import { XIcon } from './icons/Icons';

interface AdmissionModalProps {
  admissionToEdit: Admission;
  onClose: () => void;
  onSave: (admission: Admission) => void;
}

const AdmissionModal: React.FC<AdmissionModalProps> = ({ admissionToEdit, onClose, onSave }) => {
  const [formData, setFormData] = useState<Admission>({ ...admissionToEdit });
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    setFormData({ ...admissionToEdit });
  }, [admissionToEdit]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'grade' ? parseInt(value, 10) : value }));
  };

  const validate = (): boolean => {
    const newErrors: { [key: string]: string } = {};
    if (!formData.studentName.trim()) newErrors.studentName = 'Student name is required';
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email address is invalid';
    }
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (formData.phone.replace(/\D/g, '').length < 7) {
        newErrors.phone = 'Please enter a valid phone number (at least 7 digits).';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSave(formData);
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center"
      aria-modal="true"
      role="dialog"
      onClick={onClose}
    >
      <div 
        className="bg-light-card dark:bg-dark-card rounded-lg shadow-xl p-6 w-full max-w-lg m-4 relative transform transition-all"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center border-b pb-3 dark:border-dark-border">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Edit Application</h2>
          <button onClick={onClose} className="p-1 rounded-full text-light-text dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700" aria-label="Close modal">
            <XIcon />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label htmlFor="studentName" className="block text-sm font-medium text-light-text dark:text-gray-300">Student's Full Name</label>
            <input type="text" name="studentName" id="studentName" value={formData.studentName} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-light-border dark:border-dark-border rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm dark:bg-dark-bg dark:text-white" />
            {errors.studentName && <p className="text-red-500 text-xs mt-1">{errors.studentName}</p>}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
                <label htmlFor="grade" className="block text-sm font-medium text-light-text dark:text-gray-300">Grade</label>
                <select name="grade" id="grade" value={formData.grade} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-light-border dark:border-dark-border rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm dark:bg-dark-bg dark:text-white">
                {Array.from({ length: 12 }, (_, i) => i + 1).map(g => <option key={g} value={g}>{g}</option>)}
                </select>
            </div>
             <div>
                <label htmlFor="status" className="block text-sm font-medium text-light-text dark:text-gray-300">Status</label>
                <select name="status" id="status" value={formData.status} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-light-border dark:border-dark-border rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm dark:bg-dark-bg dark:text-white">
                    <option value="Pending">Pending</option>
                    <option value="Accepted">Accepted</option>
                    <option value="Rejected">Rejected</option>
                </select>
            </div>
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-light-text dark:text-gray-300">Parent Email</label>
            <input type="email" name="email" id="email" value={formData.email} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-light-border dark:border-dark-border rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm dark:bg-dark-bg dark:text-white" />
            {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
          </div>
          <div>
            <label htmlFor="phone" className="block text-sm font-medium text-light-text dark:text-gray-300">Parent Phone</label>
            <input type="text" name="phone" id="phone" value={formData.phone} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-light-border dark:border-dark-border rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm dark:bg-dark-bg dark:text-white" />
            {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
          </div>
          <div className="flex justify-end pt-4 space-x-3 border-t dark:border-dark-border mt-6">
            <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 dark:bg-gray-600 dark:text-white dark:hover:bg-gray-500 transition-colors">Cancel</button>
            <button type="submit" className="px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors">Save Changes</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AdmissionModal;
