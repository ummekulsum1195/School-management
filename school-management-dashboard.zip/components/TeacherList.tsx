import React, { useState, useMemo } from 'react';
import type { Teacher } from '../types';
import { PlusIcon, EditIcon, TrashIcon } from './icons/Icons';
import AddTeacherModal from './AddTeacherModal';

type NewTeacherData = Omit<Teacher, 'id'>;

interface TeacherListProps {
  teachers: Teacher[];
  onAddTeacher: (teacherData: NewTeacherData) => void;
  onEditTeacher: (teacher: Teacher) => void;
  onRemoveTeacher: (id: string) => void;
}

const TeacherList: React.FC<TeacherListProps> = ({ teachers, onAddTeacher, onEditTeacher, onRemoveTeacher }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<Teacher | null>(null);

  const filteredTeachers = useMemo(() => {
    return teachers.filter(teacher =>
      teacher.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      teacher.subject.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [searchTerm, teachers]);

  const handleOpenModal = (teacher: Teacher | null = null) => {
    setEditingTeacher(teacher);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingTeacher(null);
  };

  const handleSaveTeacher = (teacherData: NewTeacherData) => {
    if (editingTeacher) {
      onEditTeacher({ ...editingTeacher, ...teacherData });
    } else {
      onAddTeacher(teacherData);
    }
    handleCloseModal();
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
        <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Teacher Management</h1>
        <div className="flex items-center gap-4">
          <input
            type="text"
            placeholder="Search teachers by name or subject..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full max-w-xs px-4 py-2 border rounded-lg dark:bg-dark-card dark:border-dark-border dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-primary"
          />
          <button
            onClick={() => handleOpenModal()}
            className="flex items-center px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors shadow-md"
          >
            <PlusIcon />
            <span className="ml-2">New Teacher</span>
          </button>
        </div>
      </div>
      <div className="w-full overflow-hidden rounded-lg shadow-md">
        <div className="w-full overflow-x-auto">
          <table className="w-full whitespace-no-wrap">
            <thead>
              <tr className="text-xs font-semibold tracking-wide text-left text-light-text uppercase border-b dark:border-dark-border bg-gray-50 dark:text-gray-400 dark:bg-dark-card">
                <th className="px-4 py-3">Teacher Name</th>
                <th className="px-4 py-3">Subject</th>
                <th className="px-4 py-3">Phone</th>
                <th className="px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y dark:divide-dark-border dark:bg-dark-card">
              {filteredTeachers.map((teacher: Teacher) => (
                <tr key={teacher.id} className="text-gray-700 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800">
                  <td className="px-4 py-3">
                    <div className="flex items-center text-sm">
                      <div className="relative hidden w-8 h-8 mr-3 rounded-full md:block">
                        <img className="object-cover w-full h-full rounded-full" src={teacher.imageUrl} alt="" loading="lazy" />
                        <div className="absolute inset-0 rounded-full shadow-inner" aria-hidden="true"></div>
                      </div>
                      <div>
                        <p className="font-semibold">{teacher.name}</p>
                        <p className="text-xs text-gray-600 dark:text-gray-500">{teacher.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm">{teacher.subject}</td>
                  <td className="px-4 py-3 text-sm">{teacher.phone}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center space-x-2">
                       <button onClick={() => handleOpenModal(teacher)} className="p-1 text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors" aria-label={`Edit ${teacher.name}`}>
                         <EditIcon />
                       </button>
                       <button onClick={() => onRemoveTeacher(teacher.id)} className="p-1 text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500 transition-colors" aria-label={`Remove ${teacher.name}`}>
                         <TrashIcon />
                       </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {isModalOpen && (
        <AddTeacherModal
          teacherToEdit={editingTeacher}
          onClose={handleCloseModal}
          onSave={handleSaveTeacher}
        />
      )}
    </div>
  );
};

export default TeacherList;