import React, { useState } from 'react';
import type { Course, Teacher, Student } from '../types';
import { XIcon } from './icons/Icons';

type NewCourseData = Omit<Course, 'id'>;

interface AddCourseModalProps {
  teachers: Teacher[];
  students: Student[];
  onClose: () => void;
  onSave: (courseData: NewCourseData) => void;
}

const AddCourseModal: React.FC<AddCourseModalProps> = ({ teachers, students, onClose, onSave }) => {
  const [formData, setFormData] = useState<NewCourseData>({
    title: '',
    department: '',
    credits: 3,
    teacherId: teachers[0]?.id || '',
    studentIds: [],
  });
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: name === 'credits' ? parseInt(value, 10) : value }));
  };

  const handleStudentSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    // FIX: Explicitly type the `option` parameter as `HTMLOptionElement` to resolve the TypeScript error.
    const selectedOptions = Array.from(e.target.selectedOptions).map((option: HTMLOptionElement) => option.value);
    setFormData(prev => ({ ...prev, studentIds: selectedOptions }));
  };

  const validate = (): boolean => {
    const newErrors: { [key: string]: string } = {};
    if (!formData.title.trim()) newErrors.title = 'Title is required';
    if (!formData.department.trim()) newErrors.department = 'Department is required';
    if (formData.credits <= 0) newErrors.credits = 'Credits must be a positive number';
    if (!formData.teacherId) newErrors.teacherId = 'A teacher must be assigned';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSave(formData);
    }
  };

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-center"
      aria-modal="true"
      role="dialog"
      onClick={onClose}
    >
      <div 
        className="bg-light-card dark:bg-dark-card rounded-lg shadow-xl p-6 w-full max-w-lg m-4 relative transform transition-all"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex justify-between items-center border-b pb-3 dark:border-dark-border">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Add New Course</h2>
          <button onClick={onClose} className="p-1 rounded-full text-light-text dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700" aria-label="Close modal">
            <XIcon />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-light-text dark:text-gray-300">Course Title</label>
            <input type="text" name="title" id="title" value={formData.title} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-light-border dark:border-dark-border rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm dark:bg-dark-bg dark:text-white" />
            {errors.title && <p className="text-red-500 text-xs mt-1">{errors.title}</p>}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label htmlFor="department" className="block text-sm font-medium text-light-text dark:text-gray-300">Department</label>
              <input type="text" name="department" id="department" value={formData.department} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-light-border dark:border-dark-border rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm dark:bg-dark-bg dark:text-white" />
              {errors.department && <p className="text-red-500 text-xs mt-1">{errors.department}</p>}
            </div>
            <div>
              <label htmlFor="credits" className="block text-sm font-medium text-light-text dark:text-gray-300">Credits</label>
              <input type="number" name="credits" id="credits" min="1" value={formData.credits} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-light-border dark:border-dark-border rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm dark:bg-dark-bg dark:text-white" />
              {errors.credits && <p className="text-red-500 text-xs mt-1">{errors.credits}</p>}
            </div>
          </div>
          <div>
            <label htmlFor="teacherId" className="block text-sm font-medium text-light-text dark:text-gray-300">Assign Teacher</label>
            <select name="teacherId" id="teacherId" value={formData.teacherId} onChange={handleChange} className="mt-1 block w-full px-3 py-2 border border-light-border dark:border-dark-border rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm dark:bg-dark-bg dark:text-white">
              {teachers.length > 0 ? (
                teachers.map(t => <option key={t.id} value={t.id}>{t.name} - {t.subject}</option>)
              ) : (
                <option disabled>No teachers available</option>
              )}
            </select>
            {errors.teacherId && <p className="text-red-500 text-xs mt-1">{errors.teacherId}</p>}
          </div>
          <div>
            <label htmlFor="studentIds" className="block text-sm font-medium text-light-text dark:text-gray-300">
              Enroll Students <span className="font-normal text-xs">({formData.studentIds.length} selected)</span>
            </label>
            <select
              multiple
              name="studentIds"
              id="studentIds"
              value={formData.studentIds}
              onChange={handleStudentSelect}
              className="mt-1 block w-full px-3 py-2 border border-light-border dark:border-dark-border rounded-md shadow-sm focus:outline-none focus:ring-brand-primary focus:border-brand-primary sm:text-sm dark:bg-dark-bg dark:text-white h-32"
              aria-label="Enroll students"
            >
              {students.map(s => <option key={s.id} value={s.id}>{s.name} (Grade {s.grade})</option>)}
            </select>
            <p className="text-xs text-light-text dark:text-gray-400 mt-1">Hold Ctrl or Command to select multiple students.</p>
          </div>
          <div className="flex justify-end pt-4 space-x-3 border-t dark:border-dark-border mt-6">
            <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 dark:bg-gray-600 dark:text-white dark:hover:bg-gray-500 transition-colors">Cancel</button>
            <button type="submit" className="px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors">Save Course</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddCourseModal;