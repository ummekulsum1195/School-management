
import React, { useState, useRef, useEffect } from 'react';
import { getAIResponse } from '../services/geminiService';
import { PaperAirplaneIcon, SparklesIcon, XIcon, ChatBubbleOvalLeftEllipsisIcon } from './icons/Icons';

interface Message {
  sender: 'user' | 'ai';
  text: string;
}

interface AIAssistantProps {
  allData: object;
}

const AIAssistant: React.FC<AIAssistantProps> = ({ allData }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
      { sender: 'ai', text: "Hello! I'm your school AI assistant. How can I help you today? Try asking 'Who has the highest GPA?'" }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSend = async () => {
    if (input.trim() === '' || isLoading) return;

    const userMessage: Message = { sender: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    const aiResponseText = await getAIResponse(input, allData);
    
    const aiMessage: Message = { sender: 'ai', text: aiResponseText };
    setMessages(prev => [...prev, aiMessage]);
    setIsLoading(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 bg-brand-primary text-white p-4 rounded-full shadow-lg hover:bg-brand-primary/90 focus:outline-none focus:ring-2 focus:ring-brand-primary focus:ring-offset-2 transition-transform hover:scale-110"
        aria-label="Toggle AI Assistant"
      >
        {isOpen ? <XIcon /> : <ChatBubbleOvalLeftEllipsisIcon />}
      </button>

      {isOpen && (
        <div className="fixed bottom-24 right-6 w-full max-w-md h-[70vh] bg-light-card dark:bg-dark-card rounded-2xl shadow-2xl flex flex-col z-50 transition-all duration-300 ease-in-out">
          <header className="flex items-center justify-between p-4 border-b dark:border-dark-border">
            <div className="flex items-center">
              <SparklesIcon className="w-6 h-6 text-brand-primary mr-2" />
              <h2 className="text-lg font-bold text-gray-800 dark:text-white">AI Assistant</h2>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-light-text hover:text-gray-800 dark:text-gray-400 dark:hover:text-white">
              <XIcon />
            </button>
          </header>

          <div className="flex-1 p-4 overflow-y-auto space-y-4">
            {messages.map((msg, index) => (
              <div key={index} className={`flex items-start gap-2.5 ${msg.sender === 'user' ? 'justify-end' : ''}`}>
                {msg.sender === 'ai' && <div className="w-8 h-8 rounded-full bg-brand-secondary/20 flex items-center justify-center flex-shrink-0"><SparklesIcon className="w-5 h-5 text-brand-secondary"/></div>}
                <div className={`flex flex-col gap-1 max-w-[320px] leading-1.5 p-3 border-gray-200 ${msg.sender === 'user' ? 'bg-brand-primary text-white rounded-s-xl rounded-ee-xl' : 'bg-gray-100 dark:bg-gray-700 rounded-e-xl rounded-es-xl'}`}>
                  <p className="text-sm font-normal text-gray-900 dark:text-white whitespace-pre-wrap">{msg.text}</p>
                </div>
              </div>
            ))}
             {isLoading && (
                <div className="flex items-start gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-brand-secondary/20 flex items-center justify-center flex-shrink-0"><SparklesIcon className="w-5 h-5 text-brand-secondary"/></div>
                    <div className="flex items-center space-x-1 p-3">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse [animation-delay:-0.3s]"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse [animation-delay:-0.15s]"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                    </div>
                </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <footer className="p-4 border-t dark:border-dark-border">
            <div className="flex items-center">
              <input
                type="text"
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask anything..."
                className="flex-1 px-4 py-2 border rounded-l-lg dark:bg-dark-card dark:border-dark-border dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-primary"
                disabled={isLoading}
              />
              <button
                onClick={handleSend}
                disabled={isLoading}
                className="px-4 py-2 bg-brand-primary text-white rounded-r-lg hover:bg-brand-primary/90 disabled:bg-gray-400 disabled:cursor-not-allowed"
              >
                <PaperAirplaneIcon />
              </button>
            </div>
          </footer>
        </div>
      )}
    </>
  );
};

export default AIAssistant;
