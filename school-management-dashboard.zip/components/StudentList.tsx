import React, { useState, useMemo } from 'react';
import type { Student } from '../types';
import { PlusIcon, EditIcon, TrashIcon } from './icons/Icons';
import StudentModal from './StudentModal';

type NewStudentData = Omit<Student, 'id'>;

interface StudentListProps {
  students: Student[];
  onAddStudent: (studentData: NewStudentData) => void;
  onEditStudent: (student: Student) => void;
  onRemoveStudent: (id: string) => void;
}

const StudentList: React.FC<StudentListProps> = ({ students, onAddStudent, onEditStudent, onRemoveStudent }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  const filteredStudents = useMemo(() => {
    if (!searchTerm) return students;
    return students.filter(student =>
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.phone.includes(searchTerm)
    );
  }, [searchTerm, students]);

  const handleOpenModal = (student: Student | null = null) => {
    setEditingStudent(student);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingStudent(null);
  };

  const handleSaveStudent = (studentData: NewStudentData) => {
    if (editingStudent) {
      onEditStudent({ ...editingStudent, ...studentData });
    } else {
      onAddStudent(studentData);
    }
    handleCloseModal();
  };
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
        <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Student Management</h1>
        <div className="flex items-center gap-4">
          <input
            type="text"
            placeholder="Search students..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full max-w-xs px-4 py-2 border rounded-lg dark:bg-dark-card dark:border-dark-border dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-primary"
          />
          <button
            onClick={() => handleOpenModal()}
            className="flex items-center px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors shadow-md"
          >
            <PlusIcon />
            <span className="ml-2">New Student</span>
          </button>
        </div>
      </div>
      
      <div className="w-full overflow-hidden rounded-lg shadow-md">
        <div className="w-full overflow-x-auto">
          <table className="w-full whitespace-no-wrap">
            <thead>
              <tr className="text-xs font-semibold tracking-wide text-left text-light-text uppercase border-b dark:border-dark-border bg-gray-50 dark:text-gray-400 dark:bg-dark-card">
                <th className="px-4 py-3">Student Name</th>
                <th className="px-4 py-3">Grade</th>
                <th className="px-4 py-3">Email</th>
                <th className="px-4 py-3">Phone Number</th>
                <th className="px-4 py-3">Marks</th>
                <th className="px-4 py-3">Attendance</th>
                <th className="px-4 py-3">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y dark:divide-dark-border dark:bg-dark-card">
              {filteredStudents.map((student: Student) => (
                <tr key={student.id} className="text-gray-700 dark:text-gray-400 hover:bg-gray-50 dark:hover:bg-gray-800">
                  <td className="px-4 py-3">
                    <div className="flex items-center text-sm">
                      <div className="relative hidden w-8 h-8 mr-3 rounded-full md:block">
                        <img className="object-cover w-full h-full rounded-full" src={student.imageUrl} alt="" loading="lazy" />
                        <div className="absolute inset-0 rounded-full shadow-inner" aria-hidden="true"></div>
                      </div>
                      <div>
                        <p className="font-semibold">{student.name}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-sm">{student.grade}</td>
                  <td className="px-4 py-3 text-sm">{student.email}</td>
                  <td className="px-4 py-3 text-sm">{student.phone}</td>
                  <td className="px-4 py-3 text-sm">{student.marks}%</td>
                  <td className="px-4 py-3 text-sm">{student.attendance}%</td>
                  <td className="px-4 py-3 text-sm">
                    <div className="flex items-center space-x-2">
                       <button onClick={() => handleOpenModal(student)} className="p-1 text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 transition-colors" aria-label={`Edit ${student.name}`}>
                         <EditIcon />
                       </button>
                       <button onClick={() => onRemoveStudent(student.id)} className="p-1 text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-300 rounded-md focus:outline-none focus:ring-2 focus:ring-red-500 transition-colors" aria-label={`Remove ${student.name}`}>
                         <TrashIcon />
                       </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {isModalOpen && (
        <StudentModal
          studentToEdit={editingStudent}
          onClose={handleCloseModal}
          onSave={handleSaveStudent}
        />
      )}
    </div>
  );
};

export default StudentList;