import React, { useState } from 'react';
import { BookOpenIcon, PlusIcon, TrashIcon } from './icons/Icons';
import type { Course, Teacher, Student } from '../types';
import AddCourseModal from './AddCourseModal';

type NewCourseData = Omit<Course, 'id'>;

interface CourseListProps {
  courses: Course[];
  teachers: Teacher[];
  students: Student[];
  onAddCourse: (courseData: NewCourseData) => void;
  onRemoveCourse: (id: string) => void;
}

const CourseList: React.FC<CourseListProps> = ({ courses, teachers, students, onAddCourse, onRemoveCourse }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleSaveCourse = (courseData: NewCourseData) => {
    onAddCourse(courseData);
    setIsModalOpen(false);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
        <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Course Catalog</h1>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-brand-primary/90 transition-colors shadow-md"
        >
          <PlusIcon />
          <span className="ml-2">New Course</span>
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.map(course => {
          const teacher = teachers.find(t => t.id === course.teacherId);
          return (
            <div key={course.id} className="bg-light-card dark:bg-dark-card rounded-xl shadow-md p-6 flex flex-col justify-between hover:shadow-lg transition-shadow">
              <div>
                <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center">
                        <div className="p-2 bg-brand-secondary/10 rounded-full mr-3">
                            <BookOpenIcon className="w-6 h-6 text-brand-secondary" />
                        </div>
                        <h2 className="text-xl font-bold text-gray-800 dark:text-white pr-8">{course.title}</h2>
                    </div>
                     <button onClick={() => onRemoveCourse(course.id)} className="p-1 text-red-500 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 rounded-full hover:bg-red-100 dark:hover:bg-red-900/50" aria-label={`Remove ${course.title}`}>
                        <TrashIcon />
                    </button>
                </div>
                <p className="text-sm text-light-text dark:text-gray-400 mb-1">
                  <span className="font-semibold">Department:</span> {course.department}
                </p>
                <div className="mb-4">
                  <p className="text-sm text-light-text dark:text-gray-400">
                    <span className="font-semibold">Instructor:</span> {teacher?.name || 'N/A'}
                  </p>
                  {teacher && (
                    <p className="text-xs text-gray-500 dark:text-gray-500">{teacher.email}</p>
                  )}
                </div>
              </div>
              <div className="flex justify-between items-center text-sm text-gray-600 dark:text-gray-300 border-t dark:border-dark-border pt-4 mt-4">
                <span>{course.credits} Credits</span>
                <span>{course.studentIds.length} Students</span>
              </div>
            </div>
          );
        })}
      </div>
      {isModalOpen && (
        <AddCourseModal 
            teachers={teachers} 
            students={students}
            onClose={() => setIsModalOpen(false)} 
            onSave={handleSaveCourse} 
        />
      )}
    </div>
  );
};

export default CourseList;